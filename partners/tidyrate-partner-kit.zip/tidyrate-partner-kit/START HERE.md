# TidyRate partner kit

Thanks for joining. This kit has what you need to share TidyRate without writing everything from scratch.

## What you earn
50% of the price of every sale your link sends, tracked for 30 days after the click (the last partner link
clicked gets the sale). We pay your commissions by PayPal on the 5th of the month after the sale, once your unpaid
commissions reach $20; smaller amounts roll over to the next month until they do. If a sale is
refunded its commission is cancelled.

## Three steps
1. Sign in to your Payhip affiliate dashboard and press **Affiliate Links**. Copy the link for each product you will share.
   Use your own link, not the plain product links in `products.csv` (those do not track you).
2. Pick the product that fits your audience from `products.csv`, then use its image from `images/`, a pin from `pins/`
   and a caption from `captions.md`.
3. Put your link in the caption or the pin's destination, add your disclosure, and post.

## Disclosure (please keep it)
Say plainly that it is an affiliate link, near the link: "Affiliate link: I earn a commission if you buy through it." Follow each platform's own rules too.
Pinterest has an AI-modified label for content made with AI; we use it on our own pins.

## What the pins and images show
Preview-safe screens only: nothing in them is a full price table or the contents of a checklist or contract. Please do
the same when you write about the products (describe the result, not the numbers inside).

## Please do not
- write a first-person review of a product you have not used (ask for a free copy first);
- buy through your own link, run paid ads on the TidyRate name, or share or resell the files;
- promise earnings, or give tax or legal advice from the sheets;
- crop out the TidyRate logo from the pins.

## Want a copy to review first?
Email tidyrate@outlook.com and say which product. We send partners a free copy of anything they plan to promote.

## About the maker
TidyRate is built by someone who develops pricing and financial models for multi-million-dollar enterprise contracts for a living.
