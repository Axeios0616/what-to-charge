# Captions and hooks

Always add: Affiliate link: I earn a commission if you buy through it.

Replace `{link}` with your own tracked link from the Payhip Affiliate Links button.


## Cleaning Pricing & Contracts Kit

Fits: Cleaning business owners

**One line:** Price any cleaning job in about a minute, with the agreement and forms ready to send.

**Short description:** A pricing calculator, a service agreement, intake and estimate forms and four checklists for people who run a cleaning business. Type a home's size and condition and get a price you can defend, then send the agreement. Works in Excel and Google Sheets; the Word files are editable.


**Caption 1:** Pricing a clean without guessing: a calculator that gives a number you can defend, plus the agreement to send with it. {link}


**Caption 2:** New cleaning business? The pricing, the contract and the checklists in one download. {link}


## Cleaning Checklist Pack

Fits: Cleaning business owners and their teams

**One line:** Four checklists for every kind of clean, printable and editable.

**Short description:** Standard, deep, move-out and Airbnb-turnover checklists in printable PDF and editable Word. Train a new cleaner with a page instead of a memory, and make every visit finish the same way.


**Caption 1:** Training a new cleaner is easier with a checklist that is the same every time. {link}


**Caption 2:** Standard, deep, move-out and turnover checklists, printable or editable. {link}


## Pricing calculator for one trade (30+ trades)

Fits: Lawn, pressure washing, window, handyman, painting, pet sitting, detailing and 20+ more

**One line:** Turn your pay goal and costs into a price for any job, in Google Sheets or Excel.

**Short description:** Each calculator is built for one trade. Enter your own pay goal, costs and job sizes and it builds a quote and a price list. Every state's wage data sits behind the default numbers, so you start from something real. Pick the calculator that matches your audience's trade.


**Caption 1:** Most your trade owners guess their prices. This spreadsheet builds the quote from your own numbers. {link}


**Caption 2:** If you run a your trade business, this takes the guesswork out of pricing a job. {link}


Trade calculators (plain product links; use your own tracked ones): lawn care https://payhip.com/b/c6QRK; pressure washing https://payhip.com/b/N38xW; window cleaning https://payhip.com/b/Yz6vj; handyman https://payhip.com/b/knxOL; house painting https://payhip.com/b/Glts1; pet sitting https://payhip.com/b/FUKPm; car detailing https://payhip.com/b/IkUBi; gutter cleaning https://payhip.com/b/0QzNh; snow removal https://payhip.com/b/TSsxN; carpet cleaning https://payhip.com/b/bZ14E; junk removal https://payhip.com/b/zU1vV; Christmas light https://payhip.com/b/Hc14u


## 2027 Money Reset Bundle

Fits: Budgeting and personal-finance audiences

**One line:** Five spreadsheets for a fresh financial start in 2027.

**Short description:** A 2027 monthly budget, a debt payoff planner, a sinking funds tracker, a savings challenge and a net worth tracker. Type a few numbers and the sheets do the math. Excel and Google Sheets.


**Caption 1:** Starting 2027 with a plan: a budget, a debt plan and a savings tracker that do the math for you. {link}


**Caption 2:** Five money spreadsheets in one download, built to be filled in over a coffee. {link}


## Host Starter Bundle

Fits: Airbnb and vacation-rental hosts

**One line:** Be ready for Airbnb's new checkout rules: price the longer turnover and give your cleaner what they need.

**Short description:** A turnover cost calculator, a cleaner pack (checklist, handoff sheet, restock tracker, guest checkout card) and checkout, house rules and Wi-Fi signs. Built for the rules that apply to bookings made on or after November 20, 2026; check Airbnb's current policy before relying on any rule.


**Caption 1:** Airbnb's new checkout rules move the chores to your cleaner. This is how to price it fairly. {link}


**Caption 2:** A host starter pack for the new rules: cost calculator, cleaner checklist and guest signs. {link}


## Home Services Pricing Bundle

Fits: Handyman, painting, carpet, window and junk-removal owners

**One line:** Five pricing calculators for home-service trades in one download.

**Short description:** Handyman, house painting, carpet cleaning, window cleaning and junk removal calculators together.


**Caption 1:** Five trade pricing calculators in one download for home-service owners. {link}


## Outdoor Services Pricing Bundle

Fits: Lawn, snow, pressure washing, gutter and light-installer owners

**One line:** Five pricing calculators for outdoor services in one download.

**Short description:** Lawn care, snow removal, pressure washing, gutter cleaning and Christmas light installation calculators together.


**Caption 1:** Price lawn, snow, pressure washing, gutters and lights from one download. {link}


## Budget spreadsheets (monthly, debt payoff, Christmas planner, savings)

Fits: Personal-finance readers, frugal-living and holiday-budget audiences

**One line:** Budget spreadsheets that do the math, for Excel and Google Sheets.

**Short description:** Single-purpose sheets: a 2027 monthly budget, a debt payoff planner that compares the avalanche and snowball methods, a Christmas budget and gift planner, and a savings challenge. Type a few numbers and the rest fills in.


**Caption 1:** A debt payoff plan in a spreadsheet: it shows the order and the month you finish. {link}


**Caption 2:** Christmas on a budget: a planner that builds the shopping list as you go. {link}


**Caption 3:** A 2027 monthly budget that does the adding for you. {link}
